import java.awt.Frame;

public class RapidRollGame
{
    public static void main(String []args)
     {
        Frame f1 = new GameFrame();
        f1.setVisible(true);

        }

  }

